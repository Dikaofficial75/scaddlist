const chalk = require("chalk")
const fs = require("fs")

  global.ownerNumber = "601164299566@s.whatsapp.net"
  global.kontakOwner = "601164299566"
  global.namaStore = "Company amoi"
  global.botName = "Company amoi"
  global.ownerName = "LiaXJenny"
  
  
  global.linkyt = "link chanel yt lu"
  global.linkig = "link akun ig lu"
  global.dana = "Scan qris di atas"
  global.sawer = "Scan qris di atas"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})